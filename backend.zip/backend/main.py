from fastapi import FastAPI
from app.routes import users, group, car


app = FastAPI()

app.include_router(users)
app.include_router(group)
app.include_router(car)


