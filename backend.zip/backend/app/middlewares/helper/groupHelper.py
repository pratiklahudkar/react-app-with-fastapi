
from app.models import * 
from config import conn
from fastapi import APIRouter
from bson import ObjectId

def get_group_data_helper(id):
    if id is not None:
        base_data = entityDict(conn.local.Group.find_one({"_id":ObjectId(id)}))
        final_data = []
        for each in base_data['members']:
            found_user = entityDict(conn.local.user.find_one({"_id":ObjectId(each)}))
            user_name = found_user['name']
            new_dict = {}
            new_dict['name'] = user_name
            new_dict['id'] = str(each)
            final_data.append(new_dict)
            # base_data['members'] = list(map(lambda x: x.replace(each, user_name), base_data['members']))
        return final_data
    else:
        final_data = []
        for each in entityList(conn.local.Group.find()):
            for member in each['members']:
                base_dict = entityDict(conn.local.user.find_one({"_id":ObjectId(member)}))
                new_dict = {}
                new_dict['name'] = base_dict['name']
                new_dict['id'] = base_dict['id']
                member_pos = each['members'].index(member)
                each['members'][member_pos] = new_dict
            final_data.append(each)
        return final_data

def post_group_data_helper(group):
    new_group = {}
    new_group['name'] = dict(group)['name']
    new_group['members'] = []
    for each_member in dict(group)['members']:
        new_group['members'].append(ObjectId(each_member))
    # conn.local.Group.insert_one(new_group)
    pass