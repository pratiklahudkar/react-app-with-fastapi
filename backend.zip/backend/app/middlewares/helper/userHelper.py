from typing import final
from app.models import * 
from config import conn
from fastapi import APIRouter
from bson import ObjectId

def create_user_data_helper(user):
    conn.local.user.insert_one(dict(user))
    for each_car in dict(user)['car']:
        car_dict = {
            "name":each_car,
            "owner":dict(user)['name']
        } 
        conn.local.Car.insert_one(car_dict)
    return entityList(conn.local.user.find())

def get_user_data_helper():
    final_data = []
    for each_user in entityList(conn.local.user.find()):
        user_car_list = []
        for each_car_detail in carEntityList(conn.local.Car.find()):
            if(each_user['id'] == each_car_detail['owner']):
                car_detail_dict = {}
                car_detail_dict['name'] = each_car_detail['name']
                car_detail_dict['id'] = each_car_detail['id']
                user_car_list.append(car_detail_dict)
        user_group_list = []
        for each_group_detail in entityList(conn.local.Group.find()):
            for each_member in each_group_detail['members']:
                if(str(each_member) == each_user['id']):
                    group_detail_dict = {}
                    group_detail_dict['name'] = each_group_detail['name']
                    group_detail_dict['id'] = each_group_detail['id']
                    user_group_list.append(group_detail_dict)
        each_user['groups'] = user_group_list
        each_user['car'] = user_car_list
        final_data.append(each_user)
    return final_data


def get_each_user_data_helper(id):
    final_data = []
    for each_user in entityList(conn.local.user.find()):
        if(each_user['id'] == id):
            user_car_list = []
            for each_car_detail in carEntityList(conn.local.Car.find()):
                if(each_user['id'] == each_car_detail['owner']):
                    car_detail_dict = {}
                    car_detail_dict['name'] = each_car_detail['name']
                    car_detail_dict['id'] = each_car_detail['id']
                    user_car_list.append(car_detail_dict)
            user_group_list = []
            for each_group_detail in entityList(conn.local.Group.find()):
                for each_member in each_group_detail['members']:
                    if(str(each_member) == each_user['id']):
                        group_detail_dict = {}
                        group_detail_dict['name'] = each_group_detail['name']
                        group_detail_dict['id'] = each_group_detail['id']
                        user_group_list.append(group_detail_dict)
            each_user['groups'] = user_group_list
            each_user['car'] = user_car_list
            final_data.append(each_user)
    if(len(final_data)>0):
        return final_data
    else:
        return []